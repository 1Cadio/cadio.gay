#ifndef __MIUINPUTDRV_H__
#define __MIUINPUTDRV_H__

#include <unknwn.h>
    
DEFINE_GUID(IID_IMIUInputDrv, 0x5b3c4d5e, 0x6f7a, 0x890b, 0xc2, 0xd3, 0xe4, 0xf5, 0x06, 0x17, 0x28, 0x39);


interface IMIUInputDrv : public IUnknown {
    virtual HRESULT STDMETHODCALLTYPE Initialize() = 0;
    virtual HRESULT STDMETHODCALLTYPE StreamFrame(void *pBuffer, DWORD dwSize) = 0;
};


class CUnknown : public IUnknown {
public:
    CUnknown(const WCHAR *pName, IUnknown *pUnk) : m_cRef(0), m_pUnk(pUnk) {}
    virtual ~CUnknown() {}

    ULONG STDMETHODCALLTYPE AddRef() { return InterlockedIncrement(&m_cRef); }
    ULONG STDMETHODCALLTYPE Release() {
        ULONG cRef = InterlockedDecrement(&m_cRef);
        if (cRef == 0) delete this;
        return cRef;
    }
    HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void **ppv) {
        if (riid == IID_IUnknown) {
            *ppv = this;
            AddRef();
            return S_OK;
        }
        *ppv = NULL;
        return E_NOINTERFACE;
    }

protected:
    LONG m_cRef;
    IUnknown *m_pUnk;
};


class CMIUInputDrv : public CUnknown, public IMIUInputDrv {
public:
    CMIUInputDrv(IUnknown *pUnk, HRESULT *phr);
    virtual ~CMIUInputDrv();

    STDMETHODIMP NonDelegatingQueryInterface(REFIID riid, void **ppv);
    STDMETHODIMP Initialize();
    STDMETHODIMP StreamFrame(void *pBuffer, DWORD dwSize);

private:
    void LogMessage(const char *message);
};

#endif