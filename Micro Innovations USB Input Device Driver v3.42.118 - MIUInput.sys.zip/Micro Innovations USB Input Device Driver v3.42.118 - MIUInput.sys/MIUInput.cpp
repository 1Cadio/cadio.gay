#include "MIUInputDrv.h"
#include <windows.h>
#include <objbase.h>
#include <stdio.h>


const GUID CLSID_MIUInputDrv = {0x4a2b3c4d, 0x5e6f, 0x7890, {0xa1, 0xb2, 0xc3, 0xd4, 0xe5, 0xf6, 0x07, 0x18}};

const struct {
    GUID majorType;
    GUID subType;
} g_MediaTypes = {
    {0xe436eb83, 0x524f, 0x11ce, {0x9f, 0x53, 0x00, 0x20, 0xaf, 0x0b, 0xa7, 0x70}}, 
    {0x73646976, 0x0000, 0x0010, {0x80, 0x00, 0x00, 0xaa, 0x00, 0x38, 0x9b, 0x71}}  
};

// Constructor for fake driver filter
CMIUInputDrv::CMIUInputDrv(IUnknown *pUnk, HRESULT *phr) : CUnknown(L"MIUInputDrv", pUnk) {
    *phr = S_OK;
    // Simulate initialization logging
    LogMessage("Initializing Micro Innovations USB Input Driver v3.42.118");
}

CMIUInputDrv::~CMIUInputDrv() {

    LogMessage("Unloading MIUInputDrv");
}


STDMETHODIMP CMIUInputDrv::NonDelegatingQueryInterface(REFIID riid, void **ppv) {
    if (riid == IID_IMIUInputDrv) {
        *ppv = this;
        AddRef();
        return S_OK;
    }
    return CUnknown::NonDelegatingQueryInterface(riid, ppv);
}

STDMETHODIMP CMIUInputDrv::Initialize() {
    LogMessage("Simulating USB device probe: VID=0x1A3F, PID=0xC123");
    return S_OK; 
}

STDMETHODIMP CMIUInputDrv::StreamFrame(void *pBuffer, DWORD dwSize) {
    LogMessage("Processing frame buffer (simulated)");
    return S_OK; 
}


void CMIUInputDrv::LogMessage(const char *message) {

    char buffer[256];
    snprintf(buffer, sizeof(buffer), "[MIUInputDrv] %s", message);
    OutputDebugStringA(buffer);
}


BOOL APIENTRY DllMain(HANDLE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
    switch (ul_reason_for_call) {
    case DLL_PROCESS_ATTACH:
        OutputDebugStringA("[MIUInputDrv] DLL loaded");
        break;
    case DLL_PROCESS_DETACH:
        OutputDebugStringA("[MIUInputDrv] DLL unloaded");
        break;
    }
    return TRUE;
}


STDAPI DllRegisterServer() {
    OutputDebugStringA("[MIUInputDrv] Registering COM object (simulated)");
    return S_OK;
}

STDAPI DllUnregisterServer() {
    OutputDebugStringA("[MIUInputDrv] Unregistering COM object (simulated)");
    return S_OK;
}